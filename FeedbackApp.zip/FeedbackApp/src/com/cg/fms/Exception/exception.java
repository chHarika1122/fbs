package com.cg.fms.Exception;

public class exception extends Exception {
public exception(String message) {
	super(message);
}
}
