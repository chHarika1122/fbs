package com.capgemini.fms.service;

public interface Validator {
String name="[a-zA-Z]{6,}";
String rating="[1-5]{1}";
String subject="math||Math||English||english";
public static boolean validatedata(String data, String pattern)
{
	return data.matches(pattern);
}
}




