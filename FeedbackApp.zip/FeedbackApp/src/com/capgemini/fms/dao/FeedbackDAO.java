package com.capgemini.fms.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.capgemini.fms.bean.Feedback;
import com.cg.fms.Exception.exception;

public class FeedbackDAO implements IFeedbackDAO{
Map<String,Integer>MathFeedbackMap=new HashMap<>();
Map<String,Integer>EnglishFeedbackMap=new HashMap<>();
	@Override
	public Map<String, Integer> addFeedbackDetails(String name, int rating, String subject)throws exception {
		// TODO Auto-generated method stub
		
		/*
		 * try { String a="math"; String b="Math"; if(subject==a||subject==b) {
		 */		
		String a="math"; 
		String b="Math";
		String c="English";
		String d="english";
		if(subject==a||subject==b) {
		MathFeedbackMap.put( name, rating);
		Set set=MathFeedbackMap.entrySet();
		Iterator i=set.iterator();
		while(i.hasNext()) {
			Map.Entry me=(Map.Entry)i.next();
			//System.out.println(me.getKey()+" "+me.getValue());
		}
		}
		/*
		 * } }catch(Exception e) { System.out.println("Invalid subject"); } try { String
		 * c="English"; String d="english"; 
		 * 
		 */
		if(subject==c||subject==d) {
		EnglishFeedbackMap.put( name, rating);
			Set set1=EnglishFeedbackMap.entrySet();
			Iterator i1=set1.iterator();
			while(i1.hasNext()) {
				Map.Entry me=(Map.Entry)i1.next();
	//			System.out.println(me.getKey()+" "+me.getValue());
			}		}
	/*
		 * }catch(Exception e) { System.out.println("Invalid subject"); }
		 */
		return MathFeedbackMap;
	

	}
	@Override
	public Map<String, Integer> getFeedbackReport(String name, int rating, String subject) {
		// TODO Auto-generated method stub
Map<String,Integer>hm=new HashMap();
//String subject="";
		Feedback fb=new Feedback(name, rating, subject);
String a="math"; 
String b="Math";
String c="English";
String d="english";
if(subject.equals(a)) {
		MathFeedbackMap.put(name,rating);
		Set set=MathFeedbackMap.entrySet();
		Iterator i=set.iterator();
		while(i.hasNext()) {
			Map.Entry me=(Map.Entry)i.next();
			System.out.println(me.getKey()+" "+me.getValue());
		
		}
}
hm.putAll(MathFeedbackMap);
if(subject.equals(c)) {
			//Feedback fb=new Feedback(name, rating);
			EnglishFeedbackMap.put(name,rating);
			Set set1=EnglishFeedbackMap.entrySet();
			Iterator i1=set1.iterator();
			while(i1.hasNext()) {
				Map.Entry me1=(Map.Entry)i1.next();
				System.out.println(me1.getKey()+" "+me1.getValue());
			}
}

hm.putAll(EnglishFeedbackMap);
			
return hm;
		
	}

}
